'use client';

import React, { createContext, useContext, useState, ReactNode, useMemo, useEffect } from 'react';
import { type Campaign } from '@/lib/campaigns';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { Loader2 } from 'lucide-react';

// User and Auth types
export interface User {
  id: string;
  username: string;
  email: string;
  passwordHash: string; // In a real app, never store plain text passwords
  promoCards: number;
  notificationsEnabled: boolean;
}

export interface Notification {
  id: string;
  message: string;
  createdAt: Date;
  read: boolean;
  userId: string;
}

const mockCampaigns: Campaign[] = [];
const userAvatar = PlaceHolderImages.find(p => p.id === 'user-avatar');

type CampaignsContextType = {
  campaigns: Campaign[];
  addCampaign: (newCampaignData: Omit<Campaign, 'id' | 'creator' | 'imageUrl' | 'createdAt' | 'views' | 'status'> & { cost: number }, options?: { isAdmin?: boolean }) => void;
  updateCampaignView: (campaignId: string) => void;
  watchedCampaignIds: string[];
  notifications: Notification[];
  unreadNotificationCount: number;
  markAllAsRead: () => void;
  clearAllNotifications: () => void;
  toggleNotifications: () => void;
  // User-specific actions
  addPromoCards: (amount: number, userId?: string) => void;
  usePromoCards: (amount: number, userId?: string) => void;
  // Auth
  currentUser: User | null;
  register: (userData: Omit<User, 'id' | 'passwordHash' | 'promoCards' | 'notificationsEnabled'> & { password: string }) => { success: boolean; error?: string };
  login: (credentials: { email: string; password: string }) => { success: boolean; error?: string };
  logout: () => void;
  // Admin
  isAdminAuthenticated: boolean;
  adminLogin: (credentials: { email: string; password: string }) => { success: boolean };
  adminLogout: () => void;
  approveCampaign: (campaignId: string) => void;
  rejectCampaign: (campaignId: string) => void;
};

const CampaignsContext = createContext<CampaignsContextType | undefined>(undefined);

// A simple (and insecure) hashing function for demonstration purposes.
const simpleHash = (str: string) => {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0;
  }
  return hash.toString();
};

const ADMIN_EMAIL = "wangaistephen59@gmail.com";
const ADMIN_PASSWORD = "123456";

export const CampaignsProvider = ({ children }: { children: ReactNode }) => {
  const [campaigns, setCampaigns] = useState<Campaign[]>(mockCampaigns);
  const [watchedCampaignIds, setWatchedCampaignIds] = useState<string[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);

  // Load state from localStorage
  useEffect(() => {
    try {
      const storedCampaigns = localStorage.getItem('skytube_campaigns');
      if (storedCampaigns) setCampaigns(JSON.parse(storedCampaigns, (key, value) => key === 'createdAt' ? new Date(value) : value));
      
      const storedWatchedIds = localStorage.getItem('skytube_watched_ids');
      if (storedWatchedIds) setWatchedCampaignIds(JSON.parse(storedWatchedIds));

      const storedUsers = localStorage.getItem('skytube_users');
      if (storedUsers) {
          const parsedUsers = JSON.parse(storedUsers).map((u: Partial<User>) => ({
              ...u,
              notificationsEnabled: u.notificationsEnabled !== false, // Default to true if not set
          }));
          setUsers(parsedUsers);
      }
      
      const storedCurrentUser = localStorage.getItem('skytube_currentUser');
      if (storedCurrentUser) {
          const parsedUser = JSON.parse(storedCurrentUser);
          setCurrentUser({
              ...parsedUser,
              notificationsEnabled: parsedUser.notificationsEnabled !== false, // Default to true
          });
      }

      const storedNotifications = localStorage.getItem('skytube_notifications');
      if (storedNotifications) setNotifications(JSON.parse(storedNotifications, (key, value) => key === 'createdAt' ? new Date(value) : value));

      const storedAdminAuth = localStorage.getItem('skytube_isAdminAuthenticated');
      if (storedAdminAuth) setIsAdminAuthenticated(JSON.parse(storedAdminAuth));

    } catch (error) {
      console.error("Failed to load state from localStorage", error);
    } finally {
        setIsLoaded(true);
    }
  }, []);

  // Save state to localStorage
  useEffect(() => {
    if (!isLoaded) return;
    try {
      localStorage.setItem('skytube_campaigns', JSON.stringify(campaigns));
      localStorage.setItem('skytube_watched_ids', JSON.stringify(watchedCampaignIds));
      localStorage.setItem('skytube_users', JSON.stringify(users));
      localStorage.setItem('skytube_notifications', JSON.stringify(notifications));
      localStorage.setItem('skytube_isAdminAuthenticated', JSON.stringify(isAdminAuthenticated));
      
      if (currentUser) {
        localStorage.setItem('skytube_currentUser', JSON.stringify(currentUser));
      } else {
        localStorage.removeItem('skytube_currentUser');
      }
    } catch (error) {
      console.error("Failed to save state to localStorage", error);
    }
  }, [campaigns, watchedCampaignIds, users, notifications, currentUser, isAdminAuthenticated, isLoaded]);

  const addNotification = (message: string, userId: string) => {
    const userToNotify = users.find(u => u.id === userId);
    if (!userToNotify || !userToNotify.notificationsEnabled) return;
    
    const newNotification: Notification = {
      id: new Date().getTime().toString(),
      message,
      createdAt: new Date(),
      read: false,
      userId,
    };
    setNotifications(prev => [newNotification, ...prev]);
  };
  
  const userNotifications = useMemo(() => {
    if (!currentUser) return [];
    return notifications.filter(n => n.userId === currentUser.id).sort((a,b) => b.createdAt.getTime() - a.createdAt.getTime());
  }, [notifications, currentUser]);

  const unreadNotificationCount = useMemo(() => {
    return userNotifications.filter(n => !n.read).length;
  }, [userNotifications]);
  
  const markAllAsRead = () => {
    if (!currentUser) return;
    setNotifications(prev => prev.map(n => n.userId === currentUser.id ? { ...n, read: true } : n));
  };

  const clearAllNotifications = () => {
    if (!currentUser) return;
    setNotifications(prev => prev.filter(n => n.userId !== currentUser.id));
  };
  
  const toggleNotifications = () => {
      if (!currentUser) return;
      
      const updatedUser = { ...currentUser, notificationsEnabled: !currentUser.notificationsEnabled };
      setCurrentUser(updatedUser);

      setUsers(prevUsers => prevUsers.map(u => u.id === currentUser.id ? updatedUser : u));
  };
  
  const register = (userData: Omit<User, 'id'|'passwordHash'|'promoCards'|'notificationsEnabled'> & { password: string }) => {
    if (users.some(u => u.email === userData.email)) {
      return { success: false, error: 'An account with this email already exists.' };
    }
    
    const newUser: User = {
      id: new Date().getTime().toString(),
      username: userData.username,
      email: userData.email,
      passwordHash: simpleHash(userData.password),
      promoCards: 100, // Starting bonus
      notificationsEnabled: true,
    };
    setUsers(prev => [...prev, newUser]);
    addNotification(`Welcome to SKYTUBE! You have received 100 free Promo Cards to get started.`, newUser.id);
    return { success: true };
  };

  const login = (credentials: { email: string; password: string }) => {
    const user = users.find(u => u.email === credentials.email);
    if (!user || user.passwordHash !== simpleHash(credentials.password)) {
      return { success: false, error: 'Invalid email or password.' };
    }
    setCurrentUser(user);
    return { success: true };
  };

  const logout = () => {
    setCurrentUser(null);
    setIsAdminAuthenticated(false);
  };
  
  const usePromoCards = (amount: number, userId?: string) => {
    const targetUserId = userId || currentUser?.id;
    if (!targetUserId) return;

    setUsers(prevUsers => prevUsers.map(u => {
      if (u.id === targetUserId) {
        const updatedUser = { ...u, promoCards: Math.max(0, u.promoCards - amount) };
        if (currentUser?.id === targetUserId) {
          setCurrentUser(updatedUser);
        }
        return updatedUser;
      }
      return u;
    }));
  };

  const addPromoCards = (amount: number, userId?: string) => {
    const targetUserId = userId || currentUser?.id;
    if (!targetUserId) return;
    
    setUsers(prevUsers => prevUsers.map(u => {
      if (u.id === targetUserId) {
        const updatedUser = { ...u, promoCards: u.promoCards + amount };
         if (currentUser?.id === targetUserId) {
          setCurrentUser(updatedUser);
        }
        return updatedUser;
      }
      return u;
    }));
  };

  const addCampaign = (campaignData: Omit<Campaign, 'id' | 'creator' | 'imageUrl' | 'createdAt' | 'views'|'status'> & { cost: number }, options?: { isAdmin?: boolean }) => {
    const isAdmin = options?.isAdmin ?? false;
    let user;

    if (isAdmin) {
        user = { username: "Admin", id: 'admin' };
    } else {
        user = users.find(u => u.id === campaignData.creatorId);
        if (!user) return;
    }
    
    const newCampaign: Campaign = {
        name: campaignData.name,
        script: campaignData.script,
        maxViews: campaignData.maxViews,
        creatorId: user.id,
        id: new Date().getTime().toString(),
        views: 0,
        creator: {
            name: user.username,
            avatarUrl: userAvatar?.imageUrl || 'https://picsum.photos/seed/user-avatar/100/100'
        },
        imageUrl: `https://picsum.photos/seed/${Math.random()}/600/400`,
        createdAt: new Date(),
        status: isAdmin ? 'approved' : 'pending',
        cost: campaignData.cost,
        isAdminCampaign: isAdmin,
    };
    setCampaigns(prevCampaigns => [newCampaign, ...prevCampaigns]);
    
    if (!isAdmin) {
        addNotification(`Your promotion "${newCampaign.name}" has been submitted for review.`, user.id);
    }
  };
  
  const updateCampaignView = (campaignId: string) => {
    let campaign: Campaign | undefined;
    
    setCampaigns(prevCampaigns => 
      prevCampaigns.map(c => {
        if (c.id === campaignId) {
          campaign = c;
          return { ...c, views: c.views + 1 };
        }
        return c;
      })
    );
    
    if (campaign) {
        // Reward the campaign creator with +1 card
        if (campaign.creatorId !== 'admin') {
            addPromoCards(1, campaign.creatorId);
            addNotification(`+1 Promo Card! Your campaign "${campaign.name}" received a new, verified view.`, campaign.creatorId);
        }

        // Add to the viewer's watched list
        if (currentUser) {
            setWatchedCampaignIds(prevIds => {
                if (!prevIds.includes(campaignId)) {
                    return [...prevIds, campaignId];
                }
                return prevIds;
            });
        }
    }
  };

  // Admin functions
  const adminLogin = (credentials: {email: string, password: string}) => {
    if (credentials.email === ADMIN_EMAIL && credentials.password === ADMIN_PASSWORD) {
      setIsAdminAuthenticated(true);
      return { success: true };
    }
    return { success: false };
  }

  const adminLogout = () => {
    setIsAdminAuthenticated(false);
  }

  const approveCampaign = (campaignId: string) => {
    let campaignToUpdate: Campaign | undefined;
    setCampaigns(prev => prev.map(c => {
      if (c.id === campaignId) {
        campaignToUpdate = c;
        return {...c, status: 'approved' };
      }
      return c;
    }));
    if (campaignToUpdate) {
        addNotification(`Your promotion "${campaignToUpdate.name}" has been approved and is now live.`, campaignToUpdate.creatorId);
    }
  }

  const rejectCampaign = (campaignId: string) => {
     let campaignToUpdate: Campaign | undefined;
     setCampaigns(prev => prev.map(c => {
      if (c.id === campaignId) {
        campaignToUpdate = c;
        return {...c, status: 'rejected' };
      }
      return c;
    }));

    if (campaignToUpdate) {
        addPromoCards(campaignToUpdate.cost, campaignToUpdate.creatorId);
        addNotification(`Your promotion "${campaignToUpdate.name}" was rejected. ${campaignToUpdate.cost} Promo Cards have been refunded.`, campaignToUpdate.creatorId);
    }
  }


  const value = {
    campaigns, 
    addCampaign, 
    updateCampaignView, 
    watchedCampaignIds,
    notifications: userNotifications,
    unreadNotificationCount,
    markAllAsRead,
    clearAllNotifications,
    toggleNotifications,
    addPromoCards,
    usePromoCards,
    // Auth
    currentUser,
    register,
    login,
    logout,
    // Admin
    isAdminAuthenticated,
    adminLogin,
    adminLogout,
    approveCampaign,
    rejectCampaign,
  };

  if(!isLoaded) {
     return (
        <div className="flex items-center justify-center min-h-screen bg-background">
            <Loader2 className="h-16 w-16 animate-spin text-primary" />
        </div>
    );
  }

  return (
    <CampaignsContext.Provider value={value}>
      {children}
    </CampaignsContext.Provider>
  );
};

export const useCampaigns = () => {
  const context = useContext(CampaignsContext);
  if (context === undefined) {
    throw new Error('useCampaigns must be used within a CampaignsProvider');
  }
  return context;
};
