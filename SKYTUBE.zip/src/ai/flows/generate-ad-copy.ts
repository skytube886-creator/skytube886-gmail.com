'use server';
/**
 * @fileOverview An AI agent for generating ad headlines and body copy.
 *
 * - generateAdCopy - A function that handles the ad copy generation process.
 * - GenerateAdCopyInput - The input type for the generateAdCopy function.
 * - GenerateAdCopyOutput - The return type for the generateAdCopy function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

// Input Schema
const GenerateAdCopyInputSchema = z.object({
  productDescription: z
    .string()
    .describe('A detailed description of the product or service for which to generate ad copy.')
});
export type GenerateAdCopyInput = z.infer<typeof GenerateAdCopyInputSchema>;

// Output Schema
const GenerateAdCopyOutputSchema = z.object({
  headlines: z
    .array(z.string())
    .min(3)
    .max(5)
    .describe('A list of 3-5 compelling ad headlines.'),
  bodyCopy: z
    .string()
    .describe('A longer, descriptive body copy for the advertisement.')
});
export type GenerateAdCopyOutput = z.infer<typeof GenerateAdCopyOutputSchema>;

// Prompt definition
const generateAdCopyPrompt = ai.definePrompt({
  name: 'generateAdCopyPrompt',
  input: {schema: GenerateAdCopyInputSchema},
  output: {schema: GenerateAdCopyOutputSchema},
  prompt: `You are an expert marketing copywriter. Your task is to generate compelling ad headlines and body copy for a product or service.

Based on the following product/service description, create 3 to 5 distinct and engaging headlines, and a concise yet informative body copy. Ensure the copy is persuasive and highlights key benefits.

Product/Service Description: {{{productDescription}}}`
});

// Flow definition
const generateAdCopyFlow = ai.defineFlow(
  {
    name: 'generateAdCopyFlow',
    inputSchema: GenerateAdCopyInputSchema,
    outputSchema: GenerateAdCopyOutputSchema
  },
  async input => {
    const {output} = await generateAdCopyPrompt(input);
    if (!output) {
      throw new Error('Failed to generate ad copy.');
    }
    return output;
  }
);

// Wrapper function
export async function generateAdCopy(
  input: GenerateAdCopyInput
): Promise<GenerateAdCopyOutput> {
  return generateAdCopyFlow(input);
}
