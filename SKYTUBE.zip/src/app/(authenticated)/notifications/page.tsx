'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useCampaigns } from "@/context/CampaignsContext";
import { formatDistanceToNow } from "date-fns";
import { Bell, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function NotificationsPage() {
  const { notifications, clearAllNotifications } = useCampaigns();

  return (
    <div className="flex flex-col gap-6">
      <h1 className="text-3xl font-bold text-primary">Notifications</h1>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
            <div>
                <CardTitle>Your Notifications</CardTitle>
                <CardDescription>A log of all activity on your account.</CardDescription>
            </div>
            {notifications.length > 0 && (
                 <AlertDialog>
                    <AlertDialogTrigger asChild>
                        <Button variant="destructive" size="sm">
                            <Trash2 className="mr-2 h-4 w-4" />
                            Clear All
                        </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                        <AlertDialogHeader>
                        <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                        <AlertDialogDescription>
                            This action cannot be undone. This will permanently delete all of your
                            notifications.
                        </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={clearAllNotifications}>Continue</AlertDialogAction>
                        </AlertDialogFooter>
                    </AlertDialogContent>
                </AlertDialog>
            )}
        </CardHeader>
        <CardContent>
          {notifications.length > 0 ? (
            <div className="flex flex-col gap-4">
              {notifications.map((notification) => (
                <div key={notification.id} className="flex items-start gap-4 p-4 rounded-lg bg-muted/50 border">
                   <div className="p-2 bg-primary/20 text-primary rounded-full">
                     <Bell className="w-5 h-5" />
                   </div>
                   <div className="flex-1">
                     <p className="font-medium">{notification.message}</p>
                     <p className="text-xs text-muted-foreground">
                        {formatDistanceToNow(notification.createdAt, { addSuffix: true })}
                     </p>
                   </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center text-muted-foreground py-12 border-2 border-dashed border-border rounded-lg flex flex-col items-center gap-4">
                <Bell className="mx-auto h-12 w-12" />
                <div>
                    <p className="font-semibold">You have no notifications yet.</p>
                    <p className="text-sm">Activity from your account will show up here.</p>
                </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
