import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function PrivacyPage() {
  return (
    <div className="flex flex-col gap-6">
      <h1 className="text-3xl font-bold text-primary">Privacy Policy</h1>
      <Card>
        <CardHeader>
          <CardTitle>Your Privacy is Important</CardTitle>
          <CardDescription>Last updated: July 24, 2024</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4 text-card-foreground/90">
          <p>This Privacy Policy describes how your personal information is collected, used, and stored when you use the SKYTUBE application (the "Service").</p>

          <h3 className="font-bold text-lg text-primary/90 pt-2">1. Information We Collect</h3>
          <p>When you register for an account, we collect the following information:</p>
          <ul className="list-disc pl-6 space-y-1 text-muted-foreground">
              <li><span className="font-semibold text-card-foreground/90">Username:</span> To identify you on the platform.</li>
              <li><span className="font-semibold text-card-foreground/90">Email Address:</span> For account identification and login.</li>
              <li><span className="font-semibold text-card-foreground/90">Hashed Password:</span> We store a hashed version of your password for security.</li>
          </ul>

          <h3 className="font-bold text-lg text-primary/90 pt-2">2. How We Use Your Information</h3>
          <p>We use the information we collect solely for the purpose of providing and maintaining the Service. This includes:</p>
            <ul className="list-disc pl-6 space-y-1 text-muted-foreground">
                <li>Creating and managing your user account.</li>
                <li>Allowing you to log in and out of the service.</li>
                <li>Associating created campaigns with your user profile.</li>
            </ul>

          <h3 className="font-bold text-lg text-primary/90 pt-2">3. Data Storage and Security</h3>
          <p>
            We are committed to protecting your data. All personally identifiable information and campaign data you provide is stored on secure servers. We implement industry-standard security measures to prevent unauthorized access, use, or disclosure of your information.
          </p>

          <h3 className="font-bold text-lg text-primary/90 pt-2">4. Third-Party Services</h3>
          <p>We do not share your personal information with any third-party services. The platform is self-contained in its current state.</p>
          
          <h3 className="font-bold text-lg text-primary/90 pt-2">5. Children's Privacy</h3>
          <p>Our Service does not address anyone under the age of 13. We do not knowingly collect personally identifiable information from children under 13.</p>

          <h3 className="font-bold text-lg text-primary/90 pt-2">6. Changes to This Privacy Policy</h3>
          <p>We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page. You are advised to review this Privacy Policy periodically for any changes.</p>
        </CardContent>
      </Card>
    </div>
  );
}
