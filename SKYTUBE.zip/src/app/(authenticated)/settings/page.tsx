'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useCampaigns } from "@/context/CampaignsContext";
import { ThemeToggle } from "@/components/theme-toggle";

export default function SettingsPage() {
  const { currentUser, toggleNotifications } = useCampaigns();

  return (
    <div className="flex flex-col gap-6">
      <h1 className="text-3xl font-bold text-primary">Settings</h1>
      <Card>
        <CardHeader>
          <CardTitle>Account Settings</CardTitle>
          <CardDescription>Manage your account and theme preferences.</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-6">
           <div className="grid gap-4">
             <h3 className="font-semibold text-lg text-primary/90">Theme</h3>
             <div className="space-y-2">
                <Label>Appearance</Label>
                <p className="text-sm text-muted-foreground">Select the theme for the dashboard.</p>
                <ThemeToggle />
             </div>
           </div>
           <div className="grid gap-4">
            <h3 className="font-semibold text-lg text-primary/90">Notifications</h3>
            <div className="flex items-center justify-between rounded-lg border p-4">
                <div className="space-y-0.5">
                <Label className="text-base">Enable Notifications</Label>
                <p className="text-sm text-muted-foreground">
                    Receive notifications about your campaigns and rewards.
                </p>
                </div>
                <Switch
                    checked={currentUser?.notificationsEnabled}
                    onCheckedChange={toggleNotifications}
                    aria-label="Toggle notifications"
                />
            </div>
           </div>
        </CardContent>
      </Card>
    </div>
  );
}
