import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function TermsPage() {
  return (
    <div className="flex flex-col gap-6">
      <h1 className="text-3xl font-bold text-primary">Terms of Service</h1>
      <Card>
        <CardHeader>
          <CardTitle>Our Agreement</CardTitle>
          <CardDescription>Last updated: July 24, 2024</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4 text-card-foreground/90">
          <p>Please read these Terms of Service ("Terms", "Terms of Service") carefully before using the SKYTUBE application (the "Service") operated by us.</p>
          
          <h3 className="font-bold text-lg text-primary/90 pt-2">1. Acceptance of Terms</h3>
          <p>By creating an account and using our Service, you agree to be bound by these Terms. If you disagree with any part of the terms, then you may not access the Service.</p>

          <h3 className="font-bold text-lg text-primary/90 pt-2">2. Description of Service</h3>
          <p>SKYTUBE provides an advertising promotion platform. The service allows users ("Publishers") to submit their own third-party advertising campaigns for exposure to other users on the platform. The Service is a tool for increasing traffic and visibility; it is not a "paid-to-click" or rewards program.</p>
          
          <h3 className="font-bold text-lg text-primary/90 pt-2">3. User Accounts</h3>
          <p>To use the Service, you must register for an account by providing a username, email, and password. You are responsible for safeguarding your password and for any activities or actions under your account. You agree not to disclose your password to any third party.</p>
          
          <h3 className="font-bold text-lg text-primary/90 pt-2">4. Data Storage</h3>
          <p>
            To provide a persistent and reliable experience, all user data, including account details and campaign information, is stored securely on our servers. We take reasonable measures to protect your data from unauthorized access or disclosure.
          </p>

          <h3 className="font-bold text-lg text-primary/90 pt-2">5. User Conduct and Content</h3>
          <p>You agree not to use the Service to post any content that is unlawful, harmful, threatening, abusive, harassing, defamatory, vulgar, obscene, or otherwise objectionable. This includes a strict prohibition on adult content, malicious scripts, and promotions for illegal services. We reserve the right to remove any content and terminate accounts that violate these terms.</p>

          <h3 className="font-bold text-lg text-primary/90 pt-2">6. Termination</h3>
          <p>We may terminate or suspend your account immediately, without prior notice or liability, for any reason whatsoever, including without limitation if you breach the Terms.</p>

          <h3 className="font-bold text-lg text-primary/90 pt-2">7. Disclaimer of Warranties</h3>
          <p>The Service is provided on an "AS IS" and "AS AVAILABLE" basis. We provide no warranties of any kind, whether express or implied, including, but not limited to, implied warranties of merchantability, fitness for a particular purpose, or non-infringement.</p>

          <h3 className="font-bold text-lg text-primary/90 pt-2">8. Changes to Terms</h3>
          <p>We reserve the right, at our sole discretion, to modify or replace these Terms at any time. We will provide notice of any changes by posting the new Terms of Service on this page.</p>

          <h3 className="font-bold text-lg text-primary/90 pt-2">9. Contact Us</h3>
          <p>If you have any questions about these Terms, please see our Contact page.</p>
        </CardContent>
      </Card>
    </div>
  );
}
