'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import {
  PanelLeft,
  Tv,
  Search,
  Zap,
  Loader2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { UserNav } from '@/components/user-nav';
import { SidebarNav } from '@/components/sidebar-nav';
import { Input } from '@/components/ui/input';
import { useCampaigns } from '@/context/CampaignsContext';
import { NotificationsMenu } from '@/components/notifications-menu';
import { Skeleton } from '@/components/ui/skeleton';
import { Footer } from '@/components/footer';

function AppShell({ children }: { children: React.ReactNode }) {
  const [isMobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { currentUser } = useCampaigns();
  const [isMounted, setIsMounted] = useState(false);
  const pathname = usePathname();
  const router = useRouter();

  useEffect(() => {
    setIsMounted(true);
  }, []);
  
  useEffect(() => {
      if(isMounted && !currentUser) {
          router.push('/login');
      }
  }, [currentUser, isMounted, router]);


  if (!isMounted || !currentUser) {
    return (
        <div className="flex items-center justify-center min-h-screen bg-background">
            <Loader2 className="h-16 w-16 animate-spin text-primary" />
        </div>
    );
  }

  return (
    <div className="grid min-h-screen w-full md:grid-cols-[260px_1fr] lg:grid-cols-[260px_1fr]">
      <div className="hidden border-r bg-card md:block">
        <div className="flex h-full max-h-screen flex-col gap-2">
          <div className="flex h-14 items-center border-b px-4 lg:h-[60px] lg:px-6">
            <Link href="/dashboard" className="flex items-center gap-2 font-semibold text-primary">
              <Tv className="h-6 w-6" />
              <span className="">SKYTUBE</span>
            </Link>
          </div>
          <div className="flex-1 overflow-y-auto">
            <SidebarNav />
          </div>
        </div>
      </div>
      <div className="flex flex-col">
        <header className="flex h-14 items-center gap-4 border-b bg-background/80 backdrop-blur-sm px-4 lg:h-[60px] lg:px-6 sticky top-0 z-30">
          {isMounted ? (
            <Sheet open={isMobileMenuOpen} onOpenChange={setMobileMenuOpen}>
              <SheetTrigger asChild>
                <Button
                  variant="outline"
                  size="icon"
                  className="shrink-0 md:hidden"
                >
                  <PanelLeft className="h-5 w-5" />
                  <span className="sr-only">Toggle navigation menu</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="flex flex-col bg-card p-0">
                 <div className="flex h-14 items-center border-b px-4 lg:h-[60px] lg:px-6">
                   <Link href="/dashboard" className="flex items-center gap-2 font-semibold text-primary">
                      <Tv className="h-6 w-6" />
                      <span className="">SKYTUBE</span>
                  </Link>
                </div>
                <div className="flex-1 overflow-y-auto">
                   <SidebarNav isMobile onLinkClick={() => setMobileMenuOpen(false)} />
                </div>
              </SheetContent>
            </Sheet>
          ) : (
            <Skeleton className="h-10 w-10 shrink-0 md:hidden" />
          )}
          <div className="w-full flex-1">
            <form>
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search..."
                  className="w-full appearance-none bg-background pl-8 shadow-none md:w-2/3 lg:w-1/3"
                />
              </div>
            </form>
          </div>
          {isMounted ? <NotificationsMenu /> : <Skeleton className="h-10 w-10 rounded-full" />}
          <div className="flex items-center gap-2 rounded-full border border-border px-3 py-1.5 text-sm font-semibold">
              <Zap className="h-4 w-4 fill-primary text-primary" />
              <span>{currentUser.promoCards}</span>
          </div>
          {isMounted ? <UserNav /> : <Skeleton className="h-8 w-8 rounded-full" />}
        </header>
        <main className="flex flex-1 flex-col gap-4 p-4 lg:gap-6 lg:p-6">
          <div key={pathname} className="animate-in fade-in-0 duration-500">
            {children}
          </div>
        </main>
        <Footer />
      </div>
    </div>
  );
}

export default function AuthenticatedLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
      <AppShell>{children}</AppShell>
  );
}
