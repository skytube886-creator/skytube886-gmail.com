'use client';

import React from 'react';
import { useCampaigns } from '@/context/CampaignsContext';
import { AdminLogin } from '@/components/admin/admin-login';
import { AdminDashboard } from '@/components/admin/admin-dashboard';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AdCreator } from '@/components/campaigns/ad-creator';

export default function AdminPage() {
  const { isAdminAuthenticated } = useCampaigns();

  return (
    <div className="flex flex-col gap-6">
       <h1 className="text-3xl font-bold text-primary">Admin Panel</h1>
       {isAdminAuthenticated ? (
        <Tabs defaultValue="dashboard" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
                <TabsTrigger value="create">Create Promotion</TabsTrigger>
            </TabsList>
            <TabsContent value="dashboard">
                <AdminDashboard />
            </TabsContent>
            <TabsContent value="create">
                 <Card>
                    <CardHeader>
                        <CardTitle>Create Admin Promotion</CardTitle>
                        <CardDescription>Promotions created here are auto-approved and do not cost Promo Cards.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <AdCreator isAdminMode={true} />
                    </CardContent>
                </Card>
            </TabsContent>
        </Tabs>
       ) : (
        <Card>
            <CardHeader>
                <CardTitle>Admin Access Required</CardTitle>
                <CardDescription>You must be logged in as an administrator to access this page.</CardDescription>
            </CardHeader>
            <CardContent>
                <AdminLogin />
            </CardContent>
        </Card>
       )}
    </div>
  );
}
