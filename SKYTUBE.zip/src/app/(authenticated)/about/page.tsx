import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tv, Zap, Eye, Target, Rocket, ShieldCheck } from "lucide-react";

export default function AboutPage() {
  return (
    <div className="flex flex-col gap-6">
      <h1 className="text-3xl font-bold text-primary">About SKYTUBE</h1>
      <Card>
        <CardHeader>
          <CardTitle>A Promotional Platform for Publishers</CardTitle>
          <CardDescription>Driving real exposure to your advertising campaigns.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6 text-card-foreground/90">
          <p>
            Welcome to SKYTUBE, the premier platform designed for digital publishers and advertisers. Our mission is to provide a simple and effective solution for increasing the visibility of your online campaigns. In a competitive digital landscape, getting your content seen by a genuine audience is paramount, and SKYTUBE is the tool to help you achieve that.
          </p>
          
          <div className="grid gap-6 md:grid-cols-3">
            <div className="flex flex-col items-center gap-2 text-center p-4 rounded-lg bg-muted/50">
              <div className="p-3 bg-primary/20 text-primary rounded-full">
                <Target className="h-8 w-8" />
              </div>
              <h3 className="font-semibold text-lg">For Publishers</h3>
              <p className="text-sm text-muted-foreground">
                Easily launch campaigns for your ad scripts from any network. Drive traffic to your banners and landing pages to help meet your performance goals with your advertising partners.
              </p>
            </div>
            <div className="flex flex-col items-center gap-2 text-center p-4 rounded-lg bg-muted/50">
              <div className="p-3 bg-primary/20 text-primary rounded-full">
                <Rocket className="h-8 w-8" />
              </div>
              <h3 className="font-semibold text-lg">Instant Exposure</h3>
              <p className="text-sm text-muted-foreground">
                Your campaigns go live on our network instantly, reaching other platform users. It's a straightforward way to get more eyes on your promotional content.
              </p>
            </div>
             <div className="flex flex-col items-center gap-2 text-center p-4 rounded-lg bg-muted/50">
              <div className="p-3 bg-primary/20 text-primary rounded-full">
                <ShieldCheck className="h-8 w-8" />
              </div>
              <h3 className="font-semibold text-lg">Quality Traffic</h3>
              <p className="text-sm text-muted-foreground">
                Our system is designed to deliver genuine human visitors. We employ anti-abuse mechanisms to filter out automated traffic, ensuring your campaigns are viewed by real people.
              </p>
            </div>
          </div>

          <h2 className="text-2xl font-bold text-primary/90 pt-4 text-center">Getting Started in 3 Easy Steps</h2>
            <ol className="list-decimal list-inside space-y-4 text-muted-foreground text-center max-w-2xl mx-auto">
                <li><span className="font-semibold text-card-foreground/90">Get Your Ad Script:</span> Obtain an advertising script or a direct link from an ad network you work with (e.g., Adsterra, Google AdSense, etc.). This is the content you will be promoting.</li>
                <li><span className="font-semibold text-card-foreground/90">Create a New Campaign:</span> Navigate to the "Create Campaign" page. Give your campaign a name, paste the script, and set your desired view limit.</li>
                <li><span className="font-semibold text-card-foreground/90">Launch and Monitor:</span> Launch your campaign to make it visible across the SKYTUBE network. You can monitor its performance from your dashboard.</li>
            </ol>

          <p className="text-center pt-4">
            SKYTUBE is committed to providing a transparent and valuable service for publishers. Join us to amplify your reach and grow your audience.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
