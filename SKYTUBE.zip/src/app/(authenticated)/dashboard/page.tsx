'use client';

import React from 'react';
import Link from 'next/link';
import { Eye } from 'lucide-react';
import { CampaignCard } from '@/components/campaigns/campaign-card';
import { Button } from '@/components/ui/button';
import { useCampaigns } from '@/context/CampaignsContext';
import CreatorAdBanner from '@/components/creator-ad-banner';

export default function DashboardPage() {
    const { campaigns, watchedCampaignIds } = useCampaigns();

    // Only show approved campaigns that have not been watched by the current user
    const availableCampaigns = campaigns.filter(c => c.status === 'approved' && !watchedCampaignIds.includes(c.id));

    return (
        <div className="flex flex-col gap-6">
            <div>
              <h1 className="text-3xl font-bold text-primary">Available Promotions</h1>
              <p className="text-muted-foreground">The latest promotions are shown here. Visit an advertiser to receive a Promo Card.</p>
            </div>
            
            {availableCampaigns && availableCampaigns.length > 0 ? (
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                    {availableCampaigns.flatMap((campaign, index) => {
                        const elements = [<CampaignCard key={campaign.id} campaign={campaign} />];
                        
                        // Add an ad banner after every second campaign card.
                        if ((index + 1) % 2 === 0) {
                            elements.push(
                                <div key={`ad-${index}`} className="md:col-span-2 lg:col-span-3 xl:col-span-4 w-full flex justify-center items-center rounded-lg bg-card overflow-hidden">
                                    <CreatorAdBanner />
                                </div>
                            );
                        }
                        return elements;
                    })}
                </div>
            ) : (
                <div className="text-center text-muted-foreground py-24 border-2 border-dashed border-border rounded-lg flex flex-col items-center gap-4">
                    <Eye className="mx-auto h-12 w-12" />
                    <div>
                        <p className="font-semibold">Your promotion feed is empty.</p>
                        <p className="text-sm">Create a new promotion or wait for new ones to appear.</p>
                    </div>
                    <Button asChild>
                        <Link href="/campaigns/new">Create Promotion</Link>
                    </Button>
                </div>
            )}
        </div>
    );
}
