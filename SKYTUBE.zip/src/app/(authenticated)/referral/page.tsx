import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Mail, Phone, MessageSquare } from "lucide-react";
import { SuggestionForm } from "@/components/suggestion-form";

export default function ContactPage() {
  return (
    <div className="flex flex-col gap-6">
      <h1 className="text-3xl font-bold text-primary">Contact &amp; Suggestions</h1>
      <div className="grid gap-8 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Get in Touch</CardTitle>
            <CardDescription>We're here to help. Reach out to us through any of the channels below.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-start gap-4 p-4 rounded-lg bg-muted/50 border">
              <div className="p-2 bg-primary/20 text-primary rounded-full">
                <Mail className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-lg">Email</h3>
                <p className="text-muted-foreground">For general inquiries, support, and feedback.</p>
                <a href="mailto:skytube886@gmail.com" className="text-primary font-medium hover:underline">
                  skytube886@gmail.com
                </a>
              </div>
            </div>
            <div className="flex items-start gap-4 p-4 rounded-lg bg-muted/50 border">
              <div className="p-2 bg-primary/20 text-primary rounded-full">
                <Phone className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-lg">Phone</h3>
                <p className="text-muted-foreground">For urgent matters, you can call us directly.</p>
                <a href="tel:+254113458007" className="text-primary font-medium hover:underline">
                  +254113458007
                </a>
              </div>
            </div>
            <div className="flex items-start gap-4 p-4 rounded-lg bg-muted/50 border">
              <div className="p-2 bg-primary/20 text-primary rounded-full">
                <MessageSquare className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-lg">WhatsApp</h3>
                <p className="text-muted-foreground">Send us a message on WhatsApp for quick support.</p>
                <a href="https://wa.me/254113458007" target="_blank" rel="noopener noreferrer" className="text-primary font-medium hover:underline">
                  +254113458007
                </a>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Send a Suggestion</CardTitle>
            <CardDescription>Have feedback or an idea? We'd love to hear from you.</CardDescription>
          </CardHeader>
          <CardContent>
            <SuggestionForm />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
