import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

const faqs = [
  {
    question: "What is SKYTUBE?",
    answer: "SKYTUBE is an advertising promotion platform designed for digital publishers and creators. It allows you to launch campaigns for your advertising scripts to increase their exposure and drive traffic from a community of users."
  },
  {
    question: "How does promotion on SKYTUBE work?",
    answer: "The platform operates on a traffic exchange model. You can create a campaign by submitting an ad script from a network you work with. Your campaign is then displayed to other users on the platform. This provides a straightforward way to get more views on your ads and landing pages."
  },
  {
    question: "How do I create a campaign?",
    answer: "Simply go to the 'Create Campaign' page. You'll need to give your campaign a name, paste in the ad script or link you want to promote, and set a 'View Limit.' Once launched, your campaign will be visible to other users on the dashboard."
  },
  {
    question: "Where do I get advertising scripts to promote?",
    answer: "You obtain ad scripts from third-party advertising networks that you partner with as a publisher. Examples include networks like Adsterra, Google AdSense, PropellerAds, or any other platform that provides you with ad tags or direct links to monetize your traffic."
  },
  {
    question: "Do I get paid by SKYTUBE for using the platform?",
    answer: "No. SKYTUBE is strictly a promotional tool and does not provide any form of payment or reward to users. Our service is designed to help you increase traffic to your own ad campaigns. Any revenue you earn is paid out by the advertising network you are working with, according to their terms."
  },
  {
    question: "What advertising formats are allowed?",
    answer: "You are welcome to submit standard banner ad scripts, direct links to advertiser landing pages, and other safe promotional content. The goal is to promote legitimate products and services."
  },
  {
    question: "What advertising formats are prohibited?",
    answer: "To maintain a high-quality network, we do not permit certain types of content. This includes, but is not limited to: adult advertising scripts, promotions for illegal services, malicious scripts that harm the user experience, and any form of explicit or offensive content. Popunder advertising is also not supported at this time, but we may consider it in the future."
  },
  {
    question: "How does SKYTUBE prevent automated or bot traffic?",
    answer: "We take traffic quality very seriously. Our platform has an anti-abuse system that includes automated bot detection, monitoring of click and view patterns, and manual moderation of campaigns. We filter suspicious activity to ensure that the exposure your campaigns receive is from genuine users."
  }
];

export default function FaqPage() {
  return (
    <div className="flex flex-col gap-6">
      <h1 className="text-3xl font-bold text-primary">Frequently Asked Questions</h1>
      <Card>
        <CardHeader>
          <CardTitle>Have Questions?</CardTitle>
          <CardDescription>Find answers to common questions about SKYTUBE.</CardDescription>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <AccordionItem value={`item-${index}`} key={index}>
                <AccordionTrigger className="text-left font-semibold hover:no-underline">{faq.question}</AccordionTrigger>
                <AccordionContent className="text-muted-foreground">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </CardContent>
      </Card>
    </div>
  );
}
