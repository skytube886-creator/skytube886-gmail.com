'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useCampaigns } from "@/context/CampaignsContext";
import { format } from "date-fns";
import { Zap } from "lucide-react";

export default function HistoryPage() {
  const { campaigns, watchedCampaignIds } = useCampaigns();
  
  const watchedCampaigns = campaigns.filter(c => watchedCampaignIds.includes(c.id)).sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());

  return (
    <div className="flex flex-col gap-6">
      <h1 className="text-3xl font-bold text-primary">History</h1>
      <Card>
        <CardHeader>
          <CardTitle>Promotion History</CardTitle>
          <CardDescription>A log of all promotions you have visited.</CardDescription>
        </CardHeader>
        <CardContent>
          {watchedCampaigns.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Promotion</TableHead>
                  <TableHead>Creator</TableHead>
                  <TableHead>Visited On</TableHead>
                  <TableHead className="text-right">Promo Cards</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {watchedCampaigns.map((campaign) => (
                  <TableRow key={campaign.id}>
                    <TableCell className="font-medium">{campaign.name}</TableCell>
                    <TableCell>{campaign.creator.name}</TableCell>
                    <TableCell>{format(campaign.createdAt, 'PPP')}</TableCell>
                    <TableCell className="text-right text-primary font-semibold flex justify-end items-center gap-1">
                      +2 <Zap className="w-4 h-4" />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <p className="text-muted-foreground">Your visit history will be displayed here once you visit a promotion.</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
