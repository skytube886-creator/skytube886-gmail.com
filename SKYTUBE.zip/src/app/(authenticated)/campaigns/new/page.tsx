import { AdCreator } from "@/components/campaigns/ad-creator";

export default function NewCampaignPage() {
    return (
        <div>
            <AdCreator />
        </div>
    );
}
