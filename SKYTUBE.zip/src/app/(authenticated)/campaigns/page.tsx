'use client';

import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { PlusCircle, Eye, CheckCircle, XCircle, AlertTriangle } from "lucide-react";
import { useCampaigns } from "@/context/CampaignsContext";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { format } from "date-fns";

export default function CampaignsPage() {
  const { campaigns, currentUser } = useCampaigns();

  const myCampaigns = campaigns.filter(c => c.creatorId === currentUser?.id).sort((a,b) => b.createdAt.getTime() - a.createdAt.getTime());

  const getStatusIcon = (status: 'pending' | 'approved' | 'rejected') => {
    switch (status) {
        case 'approved':
            return <CheckCircle className="h-4 w-4 text-green-500" />;
        case 'rejected':
            return <XCircle className="h-4 w-4 text-destructive" />;
        case 'pending':
        default:
            return <AlertTriangle className="h-4 w-4 text-amber-500" />;
    }
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-primary">My Promotions</h1>
        <Button asChild>
          <Link href="/campaigns/new">
            <PlusCircle className="mr-2 h-4 w-4" /> Create New
          </Link>
        </Button>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Your Promotions</CardTitle>
          <CardDescription>
            A list of all your advertising promotions and their status.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {myCampaigns.length > 0 ? (
             <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Promotion</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead className="text-right">Views</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {myCampaigns.map((campaign) => (
                  <TableRow key={campaign.id}>
                    <TableCell className="font-medium">{campaign.name}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className={cn(
                        'capitalize flex items-center gap-1.5 w-fit',
                        campaign.status === 'approved' && 'text-green-400 border-green-400/50 bg-green-500/10',
                        campaign.status === 'rejected' && 'text-destructive border-destructive/50 bg-destructive/10',
                        campaign.status === 'pending' && 'text-amber-400 border-amber-400/50 bg-amber-500/10',
                      )}>
                        {getStatusIcon(campaign.status)}
                        {campaign.status}
                      </Badge>
                    </TableCell>
                    <TableCell>{format(campaign.createdAt, 'PPP')}</TableCell>
                    <TableCell className="text-right flex items-center justify-end gap-1">
                      <Eye className="w-4 h-4 text-muted-foreground" /> 
                      {campaign.views.toLocaleString()} / {campaign.maxViews.toLocaleString()}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-12 text-muted-foreground">
                <p>You haven't created any promotions yet.</p>
                <Button asChild variant="link" className="mt-2">
                    <Link href="/campaigns/new">Create your first one</Link>
                </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
