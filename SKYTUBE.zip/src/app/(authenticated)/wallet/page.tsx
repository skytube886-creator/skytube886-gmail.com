import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function WalletPage() {
  return (
    <div className="flex flex-col gap-6">
      <h1 className="text-3xl font-bold text-primary">Promo Cards</h1>
      <Card>
        <CardHeader>
          <CardTitle>Your Promo Cards</CardTitle>
          <CardDescription>View your Promo Card balance and history.</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">Your Promo Card activity will be displayed here.</p>
        </CardContent>
      </Card>
    </div>
  );
}
