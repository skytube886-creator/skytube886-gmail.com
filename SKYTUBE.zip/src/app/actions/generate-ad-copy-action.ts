'use server';

import { generateAdCopy, GenerateAdCopyOutput } from '@/ai/flows/generate-ad-copy';
import { z } from 'zod';

const ActionInputSchema = z.object({
  productDescription: z.string().min(10, "Please provide a more detailed description."),
});

export type ActionState = {
  formError?: string;
  generationError?: string;
  data?: GenerateAdCopyOutput;
};

export async function generateAdCopyAction(
  prevState: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const validatedFields = ActionInputSchema.safeParse({
    productDescription: formData.get('productDescription'),
  });

  if (!validatedFields.success) {
    return {
      formError: validatedFields.error.flatten().fieldErrors.productDescription?.[0],
    };
  }

  try {
    const result = await generateAdCopy(validatedFields.data);
    return { data: result };
  } catch (error) {
    console.error(error);
    return { generationError: 'Failed to generate ad copy. Please try again.' };
  }
}
