import type { Metadata } from 'next';
import './globals.css';
import { Toaster } from '@/components/ui/toaster';
import { ThemeProvider } from '@/components/theme-provider';
import { CampaignsProvider } from '@/context/CampaignsContext';

export const metadata: Metadata = {
  title: 'SKYTUBE',
  description: 'Attention-based advertising marketplace.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={'antialiased min-h-screen bg-background'}>
        <ThemeProvider defaultTheme='dark' storageKey='skytube-theme'>
          <CampaignsProvider>
            {children}
          </CampaignsProvider>
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}
