'use client';
// This is a temporary, non-persistent type definition for campaigns.
// It will be replaced once a real database is integrated.

export interface Campaign {
  id: string;
  name: string;
  creatorId: string;
  creator: {
    name: string;
    avatarUrl: string;
  };
  script: string;
  views: number;
  maxViews: number;
  imageUrl: string;
  createdAt: Date;
  status: 'pending' | 'approved' | 'rejected';
  cost: number;
  isAdminCampaign?: boolean;
}

export type NewCampaign = Omit<Campaign, 'id' | 'views' | 'imageUrl' | 'creator' | 'createdAt' | 'status' | 'cost'>;
