'use client';

import React, { useEffect, useRef } from 'react';

const CreatorAdBanner: React.FC = () => {
  const adContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const adContainer = adContainerRef.current;
    if (adContainer && adContainer.children.length === 0) {
        adContainer.innerHTML = '';
        
        const configScript = document.createElement('script');
        configScript.innerHTML = `atOptions = { 'key' : 'd6a800507c6790789aef8cbcd3890c76', 'format' : 'iframe', 'height' : 60, 'width' : 468, 'params' : {} };`;
        
        const invokeScript = document.createElement('script');
        invokeScript.src = 'https://cardinaltangible.com/d6a800507c6790789aef8cbcd3890c76/invoke.js';
        invokeScript.async = true;

        adContainer.appendChild(configScript);
        adContainer.appendChild(invokeScript);
    }
  }, []);

  // This wrapper prevents the fixed-width ad from breaking the layout on smaller screens.
  return (
    <div className="w-full overflow-x-auto flex justify-center py-2">
        <div
          ref={adContainerRef}
          className="flex justify-center items-center"
          style={{ minHeight: '60px', minWidth: '468px' }}
        />
    </div>
  );
};

export default CreatorAdBanner;
