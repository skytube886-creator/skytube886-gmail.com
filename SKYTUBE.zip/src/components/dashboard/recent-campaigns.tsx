import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
  } from "@/components/ui/card"
  import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
  } from "@/components/ui/table"
  import { Badge } from "@/components/ui/badge"
  import { cn } from "@/lib/utils"
  
  const campaigns = [
    { name: "Summer Sale 2024", status: "Active", views: "12,403" },
    { name: "New Product Launch", status: "Active", views: "8,921" },
    { name: "Holiday Special", status: "Paused", views: "21,500" },
    { name: "Q1 Branding", status: "Finished", views: "35,123" },
    { name: "Awareness Push", status: "Finished", views: "1,204" },
    { name: "Black Friday Teaser", status: "Scheduled", views: "0" },
  ];
  
  export function RecentCampaigns() {
    return (
      <Card className="h-full">
        <CardHeader>
          <CardTitle className="text-primary">Recent Campaigns</CardTitle>
          <CardDescription>An overview of your most recent ad campaigns.</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Campaign</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Views</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {campaigns.map((campaign) => (
                <TableRow key={campaign.name}>
                  <TableCell className="font-medium">{campaign.name}</TableCell>
                  <TableCell>
                    <Badge variant={'outline'} className={cn(
                        "font-semibold",
                        campaign.status === 'Active' && 'bg-primary/20 text-primary border-primary/40',
                        campaign.status === 'Paused' && 'bg-amber-500/20 text-amber-400 border-amber-500/40',
                        campaign.status === 'Finished' && 'bg-secondary text-secondary-foreground border-secondary-foreground/40',
                        campaign.status === 'Scheduled' && 'bg-blue-500/20 text-blue-400 border-blue-500/40',
                    )}>
                      {campaign.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right tabular-nums">{campaign.views}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    )
  }
  