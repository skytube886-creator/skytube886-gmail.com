'use client';
import { usePathname } from 'next/navigation';
import Link from 'next/link';
import { cn } from '@/lib/utils';
import {
  LayoutDashboard,
  PlusSquare,
  Wallet,
  History,
  Settings,
  Handshake,
  Bell,
  Info,
  ShieldCheck,
  FileText,
  MessageCircleQuestion,
  Phone,
  UserCog,
  Landmark,
} from 'lucide-react';

const mainLinks = [
  { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/notifications', label: 'Notifications', icon: Bell },
  { href: '/campaigns', label: 'My Promotions', icon: Landmark},
  { href: '/campaigns/new', label: 'Create Campaign', icon: PlusSquare },
  { href: '/wallet', label: 'Promo Cards', icon: Wallet },
  { href: '/history', label: 'History', icon: History },
];

const infoLinks = [
  { href: '/about', label: 'About Us', icon: Info },
  { href: '/faq', label: 'FAQs', icon: MessageCircleQuestion },
  { href: '/referral', label: 'Contact Us', icon: Phone },
  { href: '/terms', label: 'Terms of Service', icon: FileText },
  { href: '/privacy', label: 'Privacy Policy', icon: ShieldCheck },
];

const accountLink = [
  { href: '/settings', label: 'Settings', icon: Settings },
  { href: '/admin', label: 'Admin Panel', icon: UserCog, className: 'font-bold text-amber-400 hover:text-amber-400 hover:bg-amber-500/10' },
];

const externalLink = [
  {
    href: 'https://beta.publishers.adsterra.com/referral/psjFSQkbZy',
    label: 'Open ad account',
    icon: Handshake,
    external: true,
    className: 'font-bold text-accent hover:text-accent hover:bg-accent/10',
  },
];


type SidebarNavProps = {
  isMobile?: boolean;
  onLinkClick?: () => void;
};

export function SidebarNav({ isMobile = false, onLinkClick }: SidebarNavProps) {
  const pathname = usePathname();

  const renderLink = (link: any) => {
    const Icon = link.icon;
    const isActive = !link.external && (pathname === link.href || (link.href !== '/dashboard' && pathname.startsWith(link.href)));
    
    return (
        <Link
          key={link.href}
          href={link.href}
          target={link.external ? '_blank' : undefined}
          rel={link.external ? 'noopener noreferrer' : undefined}
          onClick={onLinkClick}
          className={cn(
            'flex items-center gap-3 rounded-lg px-3 py-3 text-white/70 transition-all hover:text-white hover:bg-white/10',
            isActive && 'bg-primary/20 text-primary hover:bg-primary/30 hover:text-primary',
            link.className
          )}
        >
          <Icon className="h-5 w-5" />
          {link.label}
        </Link>
    )
  };

  return (
    <nav className={cn('flex h-full flex-col gap-1 p-2 font-semibold', isMobile ? 'p-4' : 'px-2 py-4')}>
      <div className="flex flex-col gap-1">
        {mainLinks.map(renderLink)}
      </div>
      
      <div className="my-2 border-t border-border/50" />
      <div className="flex flex-col gap-1">
        {infoLinks.map(renderLink)}
      </div>

      <div className="mt-auto flex flex-col gap-1">
        <div className="my-2 border-t border-border/50" />
        {accountLink.map(renderLink)}
        {externalLink.map(renderLink)}
      </div>
    </nav>
  );
}
