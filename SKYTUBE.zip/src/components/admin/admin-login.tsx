'use client';

import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Loader2, ShieldAlert } from 'lucide-react';
import { useCampaigns } from '@/context/CampaignsContext';
import { useToast } from '@/hooks/use-toast';
import { Alert, AlertDescription, AlertTitle } from '../ui/alert';

const loginSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(1, 'Password is required'),
});

const MAX_ATTEMPTS = 3;
const LOCKOUT_DURATION_MS = 24 * 60 * 60 * 1000; // 24 hours

export function AdminLogin() {
  const [isLoading, setIsLoading] = useState(false);
  const [loginAttempts, setLoginAttempts] = useState(0);
  const [lockoutUntil, setLockoutUntil] = useState<number | null>(null);
  const { adminLogin } = useCampaigns();
  const { toast } = useToast();

  useEffect(() => {
    const storedAttempts = localStorage.getItem('skytube_admin_attempts');
    const storedLockout = localStorage.getItem('skytube_admin_lockout');

    if (storedLockout) {
      const lockoutTime = parseInt(storedLockout, 10);
      if (Date.now() < lockoutTime) {
        setLockoutUntil(lockoutTime);
      } else {
        // Lockout expired, clear it
        localStorage.removeItem('skytube_admin_lockout');
        localStorage.removeItem('skytube_admin_attempts');
      }
    } else if (storedAttempts) {
        setLoginAttempts(parseInt(storedAttempts, 10));
    }
  }, []);

  useEffect(() => {
    if (lockoutUntil) {
      const interval = setInterval(() => {
        if (Date.now() > lockoutUntil) {
          setLockoutUntil(null);
          setLoginAttempts(0);
          localStorage.removeItem('skytube_admin_lockout');
          localStorage.removeItem('skytube_admin_attempts');
          clearInterval(interval);
        }
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [lockoutUntil]);

  const form = useForm({
    resolver: zodResolver(loginSchema),
    defaultValues: { email: '', password: '' },
  });

  const onSubmit = async (values: z.infer<typeof loginSchema>) => {
    if (lockoutUntil) return;

    setIsLoading(true);
    const result = adminLogin(values);
    
    if (result.success) {
      toast({ title: 'Admin Login Successful' });
      localStorage.removeItem('skytube_admin_attempts');
      setLoginAttempts(0);
    } else {
      const newAttempts = loginAttempts + 1;
      setLoginAttempts(newAttempts);
      localStorage.setItem('skytube_admin_attempts', newAttempts.toString());
      
      if (newAttempts >= MAX_ATTEMPTS) {
        const newLockoutTime = Date.now() + LOCKOUT_DURATION_MS;
        setLockoutUntil(newLockoutTime);
        localStorage.setItem('skytube_admin_lockout', newLockoutTime.toString());
        toast({
          title: 'Too Many Failed Attempts',
          description: 'Admin access is locked for 24 hours.',
          variant: 'destructive',
        });
      } else {
        toast({
          title: 'Admin Login Failed',
          description: `Invalid credentials. ${MAX_ATTEMPTS - newAttempts} attempts remaining.`,
          variant: 'destructive',
        });
      }
    }
    setIsLoading(false);
  };
  
  const getRemainingLockoutTime = () => {
    if (!lockoutUntil) return '';
    const remaining = lockoutUntil - Date.now();
    const hours = Math.floor(remaining / (1000 * 60 * 60));
    const minutes = Math.floor((remaining % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((remaining % (1000 * 60)) / 1000);
    return `${hours}h ${minutes}m ${seconds}s`;
  }

  if (lockoutUntil) {
    return (
        <Alert variant="destructive">
            <ShieldAlert className="h-4 w-4" />
            <AlertTitle>Access Locked</AlertTitle>
            <AlertDescription>
                Too many failed login attempts. Please try again in {getRemainingLockoutTime()}.
            </AlertDescription>
        </Alert>
    );
  }

  return (
    <div className="max-w-sm mx-auto">
        <Alert variant="destructive" className="mb-4 bg-yellow-500/10 border-yellow-500/50 text-yellow-200">
            <ShieldAlert className="h-4 w-4 !text-yellow-400" />
            <AlertTitle>Security Warning</AlertTitle>
            <AlertDescription>
                This local admin panel is for demonstration purposes only. Do not use this authentication method in a production environment.
            </AlertDescription>
        </Alert>
        <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                <FormItem>
                    <FormLabel>Admin Email</FormLabel>
                    <FormControl>
                    <Input placeholder="admin@example.com" {...field} />
                    </FormControl>
                    <FormMessage />
                </FormItem>
                )}
            />
            <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                <FormItem>
                    <FormLabel>Admin Password</FormLabel>
                    <FormControl>
                    <Input type="password" placeholder="••••••••" {...field} />
                    </FormControl>
                    <FormMessage />
                </FormItem>
                )}
            />
            <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Log In as Admin
            </Button>
            </form>
        </Form>
    </div>
  );
}
