'use client';

import React from 'react';
import { useCampaigns } from '@/context/CampaignsContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Check, X, Eye } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import {
  Dialog,
  DialogContent,
  DialogTrigger,
} from "@/components/ui/dialog";
import { AdViewer } from '../campaigns/ad-viewer';

export function AdminDashboard() {
  const { campaigns, approveCampaign, rejectCampaign } = useCampaigns();
  const pendingCampaigns = campaigns.filter(c => c.status === 'pending');

  return (
    <Card>
      <CardHeader>
        <CardTitle>Pending Promotions</CardTitle>
        <CardDescription>Review and approve or reject new submissions.</CardDescription>
      </CardHeader>
      <CardContent>
        {pendingCampaigns.length > 0 ? (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Promotion</TableHead>
                <TableHead>Creator</TableHead>
                <TableHead>Submitted</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {pendingCampaigns.map(campaign => (
                <TableRow key={campaign.id}>
                  <TableCell className="font-medium">{campaign.name}</TableCell>
                  <TableCell>{campaign.creator.name}</TableCell>
                  <TableCell>{formatDistanceToNow(campaign.createdAt, { addSuffix: true })}</TableCell>
                  <TableCell className="text-right space-x-2">
                    <Dialog>
                      <DialogTrigger asChild>
                         <Button variant="outline" size="icon">
                            <Eye className="h-4 w-4" />
                            <span className="sr-only">Preview</span>
                         </Button>
                      </DialogTrigger>
                       <DialogContent className="max-w-3xl p-0 border-0 bg-transparent shadow-none">
                          <AdViewer campaign={campaign} />
                      </DialogContent>
                    </Dialog>
                    <Button variant="secondary" size="icon" className='bg-green-500/80 hover:bg-green-500 text-white' onClick={() => approveCampaign(campaign.id)}>
                      <Check className="h-4 w-4" />
                       <span className="sr-only">Approve</span>
                    </Button>
                    <Button variant="destructive" size="icon" onClick={() => rejectCampaign(campaign.id)}>
                      <X className="h-4 w-4" />
                       <span className="sr-only">Reject</span>
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        ) : (
          <div className="text-center text-muted-foreground py-12">
            <p>There are no pending promotions to review.</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
