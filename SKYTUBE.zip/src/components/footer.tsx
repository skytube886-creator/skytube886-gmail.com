import Link from 'next/link';

export function Footer() {
  return (
    <footer className="mt-auto border-t border-border/50 bg-card/50 text-muted-foreground">
      <div className="container mx-auto flex flex-col items-center justify-between gap-4 p-6 sm:flex-row">
        <p className="text-sm">
          &copy; 2026 SKYTUBE. All Rights Reserved.
        </p>
        <nav className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm">
          <Link href="/about" className="hover:text-primary">
            About Us
          </Link>
          <Link href="/faq" className="hover:text-primary">
            FAQs
          </Link>
          <Link href="/terms" className="hover:text-primary">
            Terms of Service
          </Link>
          <Link href="/privacy" className="hover:text-primary">
            Privacy Policy
          </Link>
          <Link href="/referral" className="hover:text-primary">
            Contact Us
          </Link>
        </nav>
      </div>
    </footer>
  );
}
