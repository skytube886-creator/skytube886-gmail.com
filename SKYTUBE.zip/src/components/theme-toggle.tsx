'use client';

import * as React from 'react';
import { Moon, Sun } from 'lucide-react';
import { useTheme } from '@/components/theme-provider';
import { Button } from '@/components/ui/button';

export function ThemeToggle() {
  const { theme, setTheme } = useTheme();

  return (
    <div className="flex items-center gap-2">
      <Button
        variant={theme === 'light' ? 'default' : 'outline'}
        size="lg"
        onClick={() => setTheme('light')}
        className="w-full justify-start gap-2"
      >
        <Sun className="h-5 w-5" />
        Light
      </Button>
      <Button
        variant={theme === 'dark' ? 'default' : 'outline'}
        size="lg"
        onClick={() => setTheme('dark')}
        className="w-full justify-start gap-2"
      >
        <Moon className="h-5 w-5" />
        Dark
      </Button>
    </div>
  );
}
