'use client';

import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useToast } from '@/hooks/use-toast';
import { Send } from 'lucide-react';
import { useCampaigns } from '@/context/CampaignsContext';

const suggestionSchema = z.object({
  email: z.string().email('Please enter a valid email address.'),
  message: z.string().min(10, 'Your message should be at least 10 characters long.'),
});

export function SuggestionForm() {
  const { toast } = useToast();
  const { currentUser } = useCampaigns();

  const form = useForm<z.infer<typeof suggestionSchema>>({
    resolver: zodResolver(suggestionSchema),
    defaultValues: {
      email: currentUser?.email || '',
      message: '',
    },
  });

  function onSubmit(values: z.infer<typeof suggestionSchema>) {
    const subject = encodeURIComponent(`Suggestion/Feedback from ${values.email}`);
    const body = encodeURIComponent(values.message);
    window.location.href = `mailto:skytube886@gmail.com?subject=${subject}&body=${body}`;

    toast({
      title: 'Opening Email Client',
      description: 'Please send the pre-filled email from your mail application.',
    });
    
    form.reset({email: currentUser?.email || '', message: ''});
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="email"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Your Email</FormLabel>
              <FormControl>
                <Input placeholder="you@example.com" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="message"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Message</FormLabel>
              <FormControl>
                <Textarea
                  placeholder="Tell us what you think or how we can improve..."
                  rows={5}
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <Button type="submit" className="w-full">
          <Send className="mr-2 h-4 w-4" />
          Send Message
        </Button>
      </form>
    </Form>
  );
}
