'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Rocket, Loader, Zap } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Slider } from '@/components/ui/slider';
import { useCampaigns } from '@/context/CampaignsContext';

const COST_PER_VIEW = 0.4; // 20 Promo Cards / 50 views

type AdCreatorProps = {
    isAdminMode?: boolean;
};

export function AdCreator({ isAdminMode = false }: AdCreatorProps) {
    const [campaignName, setCampaignName] = useState("");
    const [adScript, setAdScript] = useState("");
    const [maxViews, setMaxViews] = useState([50]);
    const [isLoading, setIsLoading] = useState(false);
    const router = useRouter();
    const { toast } = useToast();
    const { currentUser, addCampaign, usePromoCards } = useCampaigns();
    
    const promoCards = currentUser?.promoCards || 0;
    const totalCost = maxViews[0] * COST_PER_VIEW;
    const hasEnoughPromoCards = promoCards >= totalCost;

    const handleLaunch = () => {
        if (!campaignName.trim() || !adScript.trim()) {
            toast({
                title: "Incomplete Form",
                description: "Please provide a promotion name and a promotion script.",
                variant: "destructive",
            });
            return;
        }

        if (!isAdminMode && !hasEnoughPromoCards) {
            toast({
                title: "Insufficient Promo Cards",
                description: `You need ${totalCost} Promo Cards for ${maxViews[0]} views, but you only have ${promoCards}.`,
                variant: "destructive",
            });
            return;
        }
        
        if (!isAdminMode && !currentUser) {
             toast({
                title: "Not Logged In",
                description: `You must be logged in to create a promotion.`,
                variant: "destructive",
            });
            return;
        }

        setIsLoading(true);
        
        const campaignDetails = {
            name: campaignName,
            script: adScript,
            maxViews: maxViews[0],
            creatorId: currentUser?.id || 'admin',
            cost: totalCost
        };

        if (isAdminMode) {
            addCampaign(campaignDetails, { isAdmin: true });
            toast({
                title: "Admin Promotion Live!",
                description: `Your promotion "${campaignName}" is now live on the platform.`,
            });
            router.push('/dashboard');
        } else {
            usePromoCards(totalCost);
            addCampaign(campaignDetails);
            toast({
                title: "Promotion Submitted!",
                description: `Your promotion "${campaignName}" is now pending review.`,
            });
            router.push('/campaigns');
        }
    };

  return (
    <div className="grid gap-8">
        <div className="grid gap-6">
            <div className="grid gap-2">
                <Label htmlFor="campaign-name">Promotion Name</Label>
                <Input 
                    id="campaign-name" 
                    placeholder="e.g., Summer Sale 2024" 
                    value={campaignName}
                    onChange={(e) => setCampaignName(e.target.value)}
                    disabled={isLoading}
                />
            </div>
            <div className="grid gap-2">
                <Label htmlFor="ad-script">Promotion Script or Smartlink</Label>
                <Textarea 
                    id="ad-script" 
                    placeholder="Paste your promotion script or smartlink here. This will be rendered in a secure sandbox." 
                    rows={8}
                    value={adScript}
                    onChange={(e) => setAdScript(e.target.value)}
                    className="font-mono text-xs"
                    disabled={isLoading}
                />
            </div>
            <div className="grid gap-4">
                <div className="grid gap-2">
                    <Label htmlFor="max-views">View Limit ({maxViews[0].toLocaleString()})</Label>
                    <Slider
                        id="max-views"
                        min={50}
                        max={10000}
                        step={50}
                        value={maxViews}
                        onValueChange={setMaxViews}
                        disabled={isLoading}
                    />
                </div>
                {!isAdminMode && (
                    <div className="p-4 bg-muted/50 rounded-lg flex justify-between items-center">
                        <span className="font-semibold text-muted-foreground">Promotion Cost</span>
                        <span className="text-2xl font-bold text-primary flex items-center gap-1.5">
                            {totalCost} <Zap className="w-5 h-5 fill-current" />
                        </span>
                    </div>
                )}
            </div>

            <div className="flex justify-between items-center mt-4">
                <Button onClick={handleLaunch} disabled={isLoading || (!isAdminMode && !hasEnoughPromoCards)} size="lg">
                    {isLoading ? <Loader className="mr-2 animate-spin" /> : <Rocket className="mr-2" />}
                    {isLoading ? 'Submitting...' : isAdminMode ? 'Launch Promotion' : (hasEnoughPromoCards ? 'Submit for Review' : 'Insufficient Promo Cards')}
                </Button>
                {!isAdminMode && !hasEnoughPromoCards && (
                    <p className="text-sm text-destructive font-semibold">
                        You need {totalCost - promoCards} more Promo Cards.
                    </p>
                )}
            </div>
        </div>
    </div>
  )
}
