'use client';
import { type Campaign } from "@/lib/campaigns";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import Image from "next/image";
import { Eye, PlayCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogTrigger,
} from "@/components/ui/dialog";
import { AdViewer } from './ad-viewer';

export function CampaignCard({ campaign }: { campaign: Campaign }) {
  const progress = campaign.maxViews > 0 ? (campaign.views / campaign.maxViews) * 100 : 0;

  return (
    <Dialog>
        <Card className="overflow-hidden flex flex-col bg-card transition-all duration-300 hover:shadow-lg hover:shadow-primary/20 hover:-translate-y-1 group">
            <CardHeader className="p-0">
                <div className="relative h-48 w-full overflow-hidden">
                    <Image
                        src={campaign.imageUrl}
                        alt={campaign.name}
                        fill
                        style={{ objectFit: "cover" }}
                        className="transition-transform duration-500 ease-in-out group-hover:scale-105"
                        data-ai-hint="advertisement background"
                    />
                </div>
            </CardHeader>
            <CardContent className="p-4 flex-grow">
                <CardTitle className="text-lg font-bold text-primary mb-2 truncate" title={campaign.name}>{campaign.name}</CardTitle>
                <div className="flex items-center gap-3 mb-4">
                <Avatar className="h-8 w-8 border-2 border-primary/50">
                    <AvatarImage src={campaign.creator.avatarUrl} />
                    <AvatarFallback>{campaign.creator.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <span className="text-sm font-medium">{campaign.creator.name}</span>
                </div>
                
                <div>
                    <div className="flex justify-between items-center mb-1 text-xs text-muted-foreground">
                        <span className="font-semibold">Progress</span>
                        <div className="flex items-center gap-1.5">
                            <Eye className="w-4 h-4" />
                            <span className="font-semibold">{campaign.views.toLocaleString()} / {campaign.maxViews.toLocaleString()}</span>
                        </div>
                    </div>
                    <Progress value={progress} className="h-2" />
                </div>
            </CardContent>
            <CardFooter className="p-4 pt-2 grid gap-2">
                <DialogTrigger asChild>
                    <Button className="w-full bg-primary/90 hover:bg-primary text-primary-foreground font-bold">
                        <PlayCircle className="mr-2 h-4 w-4" />
                        Visit for Promo Card
                    </Button>
                </DialogTrigger>
            </CardFooter>
        </Card>
      <DialogContent className="max-w-3xl p-0 border-0 bg-transparent shadow-none">
          <AdViewer campaign={campaign} />
      </DialogContent>
    </Dialog>
  );
}
