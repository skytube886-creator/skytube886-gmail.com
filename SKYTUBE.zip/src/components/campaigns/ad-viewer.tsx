'use client';

import { useState, useEffect, useRef } from 'react';
import { type Campaign } from '@/lib/campaigns';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Zap, Loader } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { DialogTitle, DialogDescription, DialogClose } from '@/components/ui/dialog';
import { useCampaigns } from '@/context/CampaignsContext';
import { cn } from '@/lib/utils';

const AD_WATCH_DURATION = 15; // seconds

export function AdViewer({ campaign }: { campaign: Campaign }) {
  const [canClaim, setCanClaim] = useState(false);
  const [rewardClaimed, setRewardClaimed] = useState(false);
  const [adLoaded, setAdLoaded] = useState(false);
  const [adClicked, setAdClicked] = useState(false); // Tracks if the visit process has started
  
  const [timeSpentAway, setTimeSpentAway] = useState(0);
  const timeHiddenRef = useRef<number | null>(null);

  const { toast } = useToast();
  const { updateCampaignView, addPromoCards } = useCampaigns();
  const adContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = adContainerRef.current;
    if (!container || !campaign.script) return;

    // Reset state for each new ad
    setAdLoaded(false);
    setCanClaim(false);
    setRewardClaimed(false);
    setAdClicked(false);
    setTimeSpentAway(0);
    timeHiddenRef.current = null;
    container.innerHTML = '';
    
    // 1. Insert the HTML content.
    container.innerHTML = campaign.script;

    // 2. Find all script tags within the inserted HTML.
    const scriptNodes = Array.from(container.querySelectorAll('script'));
    const scriptsToLoad = scriptNodes.length;

    if (scriptsToLoad === 0) {
        setAdLoaded(true);
        return;
    }

    let scriptsLoaded = 0;
    const onScriptDone = () => {
        scriptsLoaded++;
        if (scriptsLoaded === scriptsToLoad) {
            setAdLoaded(true);
        }
    };

    // 3. Re-create and replace each script to trigger execution.
    scriptNodes.forEach(node => {
        const newScript = document.createElement('script');
        
        for (const { name, value } of node.attributes) {
            newScript.setAttribute(name, value);
        }
        
        if (node.innerHTML) {
            newScript.innerHTML = node.innerHTML;
        }

        if (newScript.src) {
            newScript.onload = onScriptDone;
            newScript.onerror = onScriptDone; // Don't block page load on a failed ad script
        }

        node.parentNode!.replaceChild(newScript, node);

        // If the script has no `src`, it's an inline script. Consider it "loaded".
        if (!newScript.src) {
            onScriptDone();
        }
    });

    return () => {
        if (container) {
            container.innerHTML = '';
        }
    };
  }, [campaign.script]);


  // Robust timer logic using the Visibility API
  useEffect(() => {
    const handleVisibilityChange = () => {
      const isVisible = document.visibilityState === 'visible';

      // Don't do anything if ad isn't loaded or reward is already claimable/claimed.
      if (!adLoaded || canClaim || rewardClaimed) {
        return;
      }

      if (!isVisible) {
        // Tab is hidden. This is our trigger to start the timer.
        if (timeHiddenRef.current === null) {
          timeHiddenRef.current = Date.now();
          if (!adClicked) {
            setAdClicked(true);
             toast({
                title: "Visit Started",
                description: "Your visit time is being recorded while you are on the advertiser's site.",
            });
          }
        }
      } else {
        // Tab is visible again. Calculate time spent away.
        if (timeHiddenRef.current !== null) {
          const durationSeconds = (Date.now() - timeHiddenRef.current) / 1000;
          timeHiddenRef.current = null; // Reset for the next time they leave.

          const newTotalTime = timeSpentAway + durationSeconds;
          setTimeSpentAway(newTotalTime);

          if (newTotalTime >= AD_WATCH_DURATION) {
            if (!canClaim) {
                setCanClaim(true);
                toast({
                    title: "Visit Verified!",
                    description: `You can now claim your reward.`,
                });
            }
          } else {
            toast({
                title: "Visit In Progress",
                description: `You were away for ${Math.round(durationSeconds)}s. Total visit time: ${Math.round(newTotalTime)}s.`,
            });
          }
        }
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [adLoaded, adClicked, canClaim, rewardClaimed, timeSpentAway, toast]);

  
  const handleClaimReward = () => {
    if (canClaim && !rewardClaimed) {
      setRewardClaimed(true);
      updateCampaignView(campaign.id);
      
      if (!campaign.isAdminCampaign) {
          addPromoCards(2);
          toast({
            title: "Promo Card Claimed!",
            description: `You've received 2 Promo Cards for visiting "${campaign.name}".`,
          });
      } else {
          toast({
            title: "Visit Confirmed",
            description: "Thank you for visiting this admin promotion.",
          });
      }
    }
  };

  const timeLeft = Math.max(0, AD_WATCH_DURATION - Math.floor(timeSpentAway));
  const timerProgress = Math.min(100, (timeSpentAway / AD_WATCH_DURATION) * 100);
  const rewardAmount = campaign.isAdminCampaign ? 0 : 2;

  const getStatusText = () => {
    if (!adLoaded) return "Waiting for promotion to load...";
    if (rewardClaimed && !campaign.isAdminCampaign) return "Promo Cards claimed. Thank you!";
    if (rewardClaimed && campaign.isAdminCampaign) return "Visit complete. Thank you!";
    if (canClaim) return "You can now claim your reward!";
    if (adClicked) {
        return `Visit in progress... ${timeLeft}s remaining.`;
    }
    return `Click the promotion. Time will be counted when you visit the advertiser's site.`;
  }

  return (
    <div className="bg-background rounded-lg overflow-hidden">
       <DialogTitle className="sr-only">{`Viewing Promotion: ${campaign.name}`}</DialogTitle>
       <DialogDescription className="sr-only">Visit the advertiser's site for {AD_WATCH_DURATION} seconds to receive your reward.</DialogDescription>
      <div 
        className="w-full h-[450px] bg-black flex items-center justify-center text-muted-foreground overflow-auto"
      >
        {!adLoaded && (
            <div className="flex items-center gap-2">
                <Loader className="animate-spin" />
                <span>Loading promotion...</span>
            </div>
        )}
        <div 
          ref={adContainerRef} 
          id="adContainer"
          className={cn("w-full h-full flex items-center justify-center", !adLoaded && "hidden")}
        />
      </div>
      <div className="p-6 bg-card border-t border-border grid gap-4">
          <div className='text-center'>
            <h3 className="text-lg font-bold text-primary">{campaign.name}</h3>
            <p className="text-muted-foreground text-sm">Visit for {AD_WATCH_DURATION} seconds to receive a reward.</p>
          </div>
          
          <div>
            <Progress value={timerProgress} className="h-2 mb-2" />
            <div className="flex justify-between items-center text-xs text-muted-foreground">
                <span>
                    {getStatusText()}
                </span>
                <span className="font-semibold text-primary flex items-center gap-1">
                    Reward: +{rewardAmount} Promo Cards <Zap className="w-3 h-3" />
                </span>
            </div>
          </div>
            <DialogClose asChild>
                <Button 
                    onClick={handleClaimReward} 
                    disabled={!canClaim || rewardClaimed}
                    size="lg"
                    className="w-full font-bold"
                >
                    {rewardClaimed ? 'Reward Claimed' : 'Claim Reward'}
                </Button>
            </DialogClose>
      </div>
    </div>
  );
}
