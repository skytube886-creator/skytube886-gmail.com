'use client';

import Link from 'next/link';
import { Bell } from 'lucide-react';
import { useCampaigns } from '@/context/CampaignsContext';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuGroup,
} from '@/components/ui/dropdown-menu';
import { formatDistanceToNow } from 'date-fns';

export function NotificationsMenu() {
  const { notifications, unreadNotificationCount, markAllAsRead } = useCampaigns();
  const recentNotifications = notifications.slice(0, 5);

  const handleOpenChange = (open: boolean) => {
    if (open && unreadNotificationCount > 0) {
      // Use a timeout to avoid marking as read before the user can see them
      setTimeout(() => {
        markAllAsRead();
      }, 1000);
    }
  };

  return (
    <DropdownMenu onOpenChange={handleOpenChange}>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="relative rounded-full">
          <Bell className="h-5 w-5" />
          {unreadNotificationCount > 0 && (
            <span className="absolute top-1 right-1 flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-primary"></span>
            </span>
          )}
          <span className="sr-only">Notifications</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-80" align="end">
        <DropdownMenuLabel>
          <div className="flex justify-between items-center">
            <span className="font-bold">Notifications</span>
            {unreadNotificationCount > 0 && (
              <span className="text-xs font-bold bg-primary text-primary-foreground rounded-full px-2 py-0.5">
                {unreadNotificationCount} new
              </span>
            )}
          </div>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuGroup>
          {recentNotifications.length > 0 ? (
            recentNotifications.map(notification => (
              <DropdownMenuItem key={notification.id} className="flex items-start gap-3 whitespace-normal">
                <div className={`mt-1 h-2 w-2 rounded-full ${!notification.read ? 'bg-primary' : 'bg-muted-foreground/50'}`}></div>
                <div className="flex-1">
                  <p className="text-sm">{notification.message}</p>
                  <p className="text-xs text-muted-foreground">
                    {formatDistanceToNow(notification.createdAt, { addSuffix: true })}
                  </p>
                </div>
              </DropdownMenuItem>
            ))
          ) : (
            <DropdownMenuItem disabled>
              <div className="text-center py-4 w-full">
                <p className="text-sm text-muted-foreground">You have no new notifications.</p>
              </div>
            </DropdownMenuItem>
          )}
        </DropdownMenuGroup>
        <DropdownMenuSeparator />
        <DropdownMenuItem asChild>
          <Link href="/notifications" className="justify-center cursor-pointer">
            View all notifications
          </Link>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
